document.getElementById("weatherForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const location = document.getElementById("locationInput").value;
  const apiKey = "3b01abb6d37043a580a52001252910";
  const apiUrl = `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${location}&aqi=yes`;

  try {
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error("Location not found");
    }

    const data = await response.json();

    document.getElementById("cityName").textContent = `${data.location.name}, ${data.location.country}`;
    document.getElementById("temperature").textContent = `🌡 Temperature: ${data.current.temp_c}°C`;
    document.getElementById("condition").textContent = `☁ Condition: ${data.current.condition.text}`;
    document.getElementById("weatherIcon").src = "https:" + data.current.condition.icon;

    document.getElementById("weatherResult").classList.remove("hidden");
  } catch (error) {
    alert(error.message);
  }
});
