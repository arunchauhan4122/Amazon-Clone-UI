#include <iostream>
using namespace std;

int main() {
    int num, product = 1, digit;

    cout << "Enter number: ";
    cin >> num;
    for (int n=num; n>0; n=n/10) 
    {
        digit = n % 10;
        product *= digit;
    }

    cout << "Product is: " << " " << product << endl;

    
}
